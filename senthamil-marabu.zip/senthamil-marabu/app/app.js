// app/app.js — Senthamil Marabu bundle loader
// Usage: include <script src="app/app.js"></script>; then SenthamilApp.init()
const SenthamilApp = (() => {
  let bundle = null;
  let index = null;
  // --- Load & index -----------------------------------------------------
  async function init(bundleUrl = './build/bundle.json') {
    const res = await fetch(bundleUrl);
    if (!res.ok) throw new Error(`Bundle load failed: ${res.status}`);
    bundle = await res.json();
    index = buildIndexes(bundle);
    return { meta: bundle.meta, counts: bundle.counts };
  }
  function buildIndexes(b) {
    const byId = new Map();
    const byOthu = new Map();
    const byKind = new Map();
    const byKuri = new Map();
    const byLetter = new Map();
    const criteria = new Map();   // id → [ids it serves as criterion for]
    const citations = new Map();  // id → [ids that cite it]
    for (const r of b.sutras) {
      byId.set(r.id, r);
      pushTo(byOthu, `${r.adhikaram}.${r.othu}`, r.id);
      pushTo(byKind, r.computer.kind, r.id);
      pushTo(byKuri, r.kuri, r.id);
      pushTo(byLetter, tamilFirstLetter(r.verse), r.id);
      const nk = r.nul_kurum || {};
      for (const t of nk.criterion_for || []) pushTo(criteria, r.id, t);
      for (const l of [...(r.links||[]), ...(nk.refs||[]), ...(nk.criterion_for||[])]) {
        pushTo(citations, l, r.id);
      }
    }
    return { byId, byOthu, byKind, byKuri, byLetter, criteria, citations };
  }
  function pushTo(map, key, val) {
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(val);
  }
  // --- Query API --------------------------------------------------------
  function get(id) {
    return index.byId.get(id) || null;
  }
  function getOthu(adhikaram, othu) {
    const ids = index.byOthu.get(`${adhikaram}.${othu}`) || [];
    return ids.map(id => index.byId.get(id));
  }
  function getKind(kind) {
    return (index.byKind.get(kind) || []).map(id => index.byId.get(id));
  }
  function getKuri(kuri) {
    return (index.byKuri.get(kuri) || []).map(id => index.byId.get(id));
  }
  function getByLetter(ch) {
    return (index.byLetter.get(ch) || []).map(id => index.byId.get(id));
  }
  function criterionFor(id) {
    return (index.criteria.get(id) || []).map(i => index.byId.get(i));
  }
  function citedBy(id) {
    return (index.citations.get(id) || []).map(i => index.byId.get(i));
  }
  // --- Full-text search (whitespace + case-insensitive) ----------------
  function search(q) {
    if (!q || !q.trim()) return [];
    const needle = normalize(q);
    const results = [];
    for (const r of bundle.sutras) {
      const hay = normalize(
        `${r.verse} ${r.kaandigai} ${(r.nul_kurum || {}).text || ''} ${r.viparam || ''}`
      );
      if (hay.includes(needle)) {
        results.push({ id: r.id, score: scoreResult(r, needle) });
      }
    }
    return results.sort((a, b) => b.score - a.score).map(x => index.byId.get(x.id));
  }
  function scoreResult(r, needle) {
    let s = 0;
    if (normalize(r.verse).includes(needle)) s += 10;
    if (normalize(r.kaandigai).includes(needle)) s += 5;
    if (normalize((r.nul_kurum||{}).text||'').includes(needle)) s += 3;
    return s;
  }
  function normalize(s) {
    return (s || '').replace(/\s+/g, '').toLowerCase();
  }
  function tamilFirstLetter(verse) {
    // first Tamil akshara (simplistic: first char)
    return (verse || '').trim().charAt(0);
  }
  // --- Render helper (extensible) --------------------------------------
  function renderRecord(id) {
    const r = get(id);
    if (!r) return null;
    const nk = r.nul_kurum || {};
    return {
      header: `${r.id} · ${r.kuri} · ${r.computer.kind}`,
      layers: [
        { name: 'செய்யுள்',     body: r.verse },
        { name: 'காண்டிகை',    body: r.kaandigai },
        { name: 'நூல் கூறும் உரை', body: `[${nk.function}] ${nk.text || ''}` },
        { name: 'விபரம்',       body: r.viparam || '' },
        { name: 'குறி',         body: r.kuri + (nk.kuri ? ` / ${nk.kuri}` : '') },
        { name: 'கணினி',        body: JSON.stringify(r.computer) },
      ],
      criterion_for: criterionFor(id).map(x => x.id),
      cited_by: citedBy(id).map(x => x.id),
    };
  }
  // --- Public API -------------------------------------------------------
  return {
    init, get, getOthu, getKind, getKuri, getByLetter,
    criterionFor, citedBy, search, renderRecord,
    get bundle() { return bundle; },
  };
})();
// --- Example usage in a page -----------------------------------------
// document.addEventListener('DOMContentLoaded', async () => {
//   await SenthamilApp.init('./build/bundle.json');
//   console.log('Loaded', SenthamilApp.bundle.meta.total_sutras, 'sutras');
//   console.log(SenthamilApp.get('ezhu.1'));
//   console.log('othu 1:', SenthamilApp.getOthu('ezhuthu', 1).map(x => x.id));
//   console.log('criterion:', SenthamilApp.criterionFor('ezhu.1').map(x => x.id));
//   console.log('search:', SenthamilApp.search('குற்றியலுகரம்').map(x => x.id));
// });
